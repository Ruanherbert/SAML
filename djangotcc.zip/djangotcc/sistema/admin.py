from django.contrib import admin
from django.contrib.auth import admin as auth_admin
from .models import Aluno, Orientador, Monitor, Monitoria, User
from sistema.forms import UserChangeForm, UserCreationForm


@admin.register(User)
class UserAdmin(auth_admin.UserAdmin):
    form = UserChangeForm
    add_form = UserCreationForm
    model = User
    fieldsets = auth_admin.UserAdmin.fieldsets + (
        ("Campos Personalizados", {"fields": ("nome", "curso", "disciplina")}),
    )

@admin.register(Aluno)
class AlunoAdmin(admin.ModelAdmin):
    model = Aluno
    list_display = ('user',)


@admin.register(Monitor)
class MonitorAdmin(admin.ModelAdmin):
    model = Monitor
    list_display = ('user',)


@admin.register(Orientador)
class OrientadorAdmin(admin.ModelAdmin):
    model = Orientador
    list_display = ('user', 'disciplina',)

# Coloca opção 1 e digita qualquer coisa


admin.site.register(Monitoria)
