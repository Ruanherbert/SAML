from django.db import models
from django.contrib.auth.models import AbstractUser, User


class User(AbstractUser):
    disciplina = models.CharField(max_length=30)
    nome = models.CharField(max_length=150)
    curso = models.CharField(max_length=20)


# Executa


class Aluno(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)

    def __str__(self):
        return 'Nome: {}, Matrícula: {}'.format(self.user.nome, self.user.username)


class Monitor(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    disciplina = models.CharField(max_length=30)

    def __str__(self):
        return '{}'.format(self.user.nome)


class Orientador(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    disciplina = models.CharField(max_length=30)

    def __str__(self):
        return 'Nome: {}, Matrícula: {}'.format(self.nome, self.username)


class Monitoria(models.Model):
    disciplina = models.CharField(max_length=30)
    horario = models.TimeField()
    monitor = models.ForeignKey(Monitor, on_delete=models.CASCADE)

    def __str__(self):
        return 'Disciplina: {} - Horário: {} - Monitor: {}'.format(self.disciplina,  self.horario, self.monitor.nome)


class AgendarMonitoria(models.Model):
    assunto = models.CharField(max_length=250)
    observacao = models.TextField()
