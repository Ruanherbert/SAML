from django import forms
from django.contrib.auth import models
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from django.core.exceptions import ValidationError
from django.contrib.auth import forms
from .models import User


class UserChangeForm(forms.UserChangeForm):
    class Meta(forms.UserChangeForm.Meta):
        model = User


class UserCreationForm(forms.UserCreationForm):
    class Meta(forms.UserCreationForm.Meta):
        model = User


class AlunoForm(UserCreationForm):
    class Meta:
        model = User
        fields = ['username', 'nome', 'curso',
                  'email', 'password1', 'password2']

    def clean_email(self):
        e = self.cleaned_data['email']
        if User.objects.filter(email=e).exists():
            raise ValidationError('O E-mail: {} já está cadastrado.'.format(e))
        return e

# Buguei


class MonitorForm(UserCreationForm):
    class Meta:
        model = User
        fields = ['username', 'nome', 'curso',
                  'disciplina', 'email', 'password1', 'password2']

    def clean_email(self):
        e = self.cleaned_data['email']
        if User.objects.filter(email=e).exists():
            raise ValidationError('O E-mail: {} já está cadastrado.'.format(e))
        return e


class OrientadorForm(UserCreationForm):

    class Meta:
        model = User
        fields = ['username', 'nome', 'curso',
                  'disciplina', 'email', 'password1', 'password2']

    def clean_email(self):
        e = self.cleaned_data['email']
        if User.objects.filter(email=e).exists():
            raise ValidationError('O E-mail: {} já está cadastrado.'.format(e))
        return e
